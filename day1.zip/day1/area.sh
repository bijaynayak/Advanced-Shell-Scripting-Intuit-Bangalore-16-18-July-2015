#!/usr/bin/bash

read -p 'enter radius :' radius

area=`echo "scale=16; 3.142 * $radius ^ 2" | bc`

printf "radius : %s\narea: %.3f\n" $radius $area

