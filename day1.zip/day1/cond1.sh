#!/usr/bin/bash

read -p 'enter the value :' value

if [[ $value -gt 5 ]]; then
	((result = value * value))	
else
	result=$((value * value * value))		
fi

echo  "result  : $result"

