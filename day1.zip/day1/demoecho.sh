#!/bin/bash

echo -ne "user\tid : $UID"
echo -n "$HOSTNAME"

echo $PWD

