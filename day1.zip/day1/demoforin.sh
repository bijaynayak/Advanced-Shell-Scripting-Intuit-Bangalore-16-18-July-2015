#!/usr/bin/bash

read -p 'enter the dir :' dirname
echo "$dirname :"
for item in $(ls  $dirname)
do
	set -x
	read 

	if [[ -f  $dirname/$item ]]
	then
		size=$(stat --printf "%s" $dirname/$item)
		set +x
		printf "%32s : %s\n" $item $size
   	fi
done