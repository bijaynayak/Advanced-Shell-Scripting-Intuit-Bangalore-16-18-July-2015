PS3="enter your choice :"

select option in users memory fsstat exit
do
	case $option in
	 	users) w ;;
	 	memory) 
			if [[ $(uname) == 'Linux' ]]; then
				free -m
			else
				echo "option not supported"
			fi
			;;		
	 	fsstat) df -h;;
	 	exit)  exit 0;;
	 	*)  echo "$0: $option: Invalid option" 	
	 esac 
done 