name='tp'

echo -e "name:\t$name"
echo -e 'name:\t$name'

echo -e "name:\t$HOSTNAME"
echo -e 'name:\t$HOSTNAME'

s="<table id='1'><tr><td>tab1</td></tr></table>"
s2='intuit'
echo $s$s2