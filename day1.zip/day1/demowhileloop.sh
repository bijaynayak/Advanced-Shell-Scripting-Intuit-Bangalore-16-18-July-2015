i=1
while ((i <= 10))
do
	if ((i==1)); then
		echo 'one'
	elif ((i==2)); then
		echo 'ii'
	elif ((i==4)); then
		((i++))
		continue
		echo 'unreachable line'	
	elif ((i==6)); then
		break		
	else
		echo $i
	fi		
	((i++))
done 