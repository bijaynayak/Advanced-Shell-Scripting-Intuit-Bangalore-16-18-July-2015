#!/usr/bin/bash

handle_error(){
	code=$1
	if ((code==32));then 
		echo "got error code $code"
	elif ((code==33));then
		echo "got a fancy error code $code"
	fi
}

hostname=`hostname`
if [[ $hostname != 'localhost.localdomain' ]]
then
	errcode=32
	handle_error $errcode
fi	
 
w | grep 'training' &> /dev/null

if [[ $? -ne 0 ]]
then
	errcode=33
	handle_error $errcode
fi


