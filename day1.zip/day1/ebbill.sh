read -p 'enter the units :' units

if ((units <= 100)); then
	amount=$units
elif ((units <= 200)); then
	amount=`echo "$units * 1.5" | bc`
elif ((units <= 500)); then
	amount=`echo "(200 * 2) + ($units-200) * 3" | bc`
elif ((units > 500)); then
	amount=`echo "(200 * 3) + (300 * 4) + ($units-500) * 5.75" | bc`
fi

printf "billable : %.2f\n" $amount
	#statements
