
compute() {
	units=$1
	if ((units <= 100)); then
		amount=$units
	elif ((units <= 200)); then
		amount=`echo "$units * 1.5" | bc`
	elif ((units <= 500)); then
		amount=`echo "(200 * 2) + ($units-200) * 3" | bc`
	elif ((units > 500)); then
		amount=`echo "(200 * 3) + (300 * 4) + ($units-500) * 5.75" | bc`
	fi
	echo $amount
}	

#read -p 'enter the units :' units
#echo $(compute $units)
atfirst=1
outputfile='amount.csv'
{
cat monthlyreading.csv | while read line
do  
	serialno=$(echo $line | cut -f 1 -d ',')
	units=$(echo $line | cut -f 3 -d ',')
	if (( atfirst == 1 )); then
		atfirst=0
		echo "serialno,amount" 
		continue	
	fi
	amount=$(compute $units)
	echo "$serialno,$amount" 
done
} > $outputfile 

join -t ',' monthlyreading.csv amount.csv

	
