#!/bin/bash

echo $NAME

