#!/usr/bin/bash

read -p 'enter the file name :' filename

if [[ ! -f $filename ]]; then
	echo "$0: $filename: file not found"
	exit
fi	

filesize=$(stat --printf "%s" $filename)
echo "file name : $filename"
echo "file size : $filesize"

user=$(stat --printf "%U" $filename)
echo "user : $user"
