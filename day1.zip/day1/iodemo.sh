#!/usr/bin/bash
echo -n 'enter the name'
read  name
echo -n 'enter the city :'
read  city

value=$(echo $name | tr 'a-z' 'A-Z')   #command sub.
value1=$(echo $city | tr 'a-z' 'A-Z')

echo "name: $value"
echo "city: $value1"
