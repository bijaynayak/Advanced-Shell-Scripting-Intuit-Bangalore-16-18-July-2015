#!/usr/bin/bash

read -p 'enter the hostname :' hostname

ping -c 2 $hostname &> /dev/null

(($? == 0)) && { echo "$hostname: up"; } || { echo "$hostname: down"; }

